define('Mobile/Template/Views/Account/List', [
    'dojo/_base/declare',
    'dojo/string',
    'Sage/Platform/Mobile/List'
], function(
    declare,
    string,
    List
) {
    return declare('Mobile.Template.Views.Account.List', [List], {
        // Localization
        titleText: 'Account List',
        
        // View Properties
        id: 'account_list',
        detailView: 'account_detail',
        insertView: 'account_edit',
        icon: 'content/images/icons/Company_24.png',
        resourceKind: 'accounts',
        querySelect: [
            'AccountName',
            'AccountManager/UserInfo/Username'
        ],
        queryOrderBy: 'AccountName asc',
        
        // Templates
        itemTemplate: new Simplate([
            '<h3>{%: $.AccountName %}</h3>',
            '<h4>{%: $.AccountManager && $.AccountManager.UserInfo ? $.AccountManager.UserInfo.UserName : "" %}</h4>'
        ])
        
    });
});