define('Mobile/Template/Views/Account/Edit', [
    'dojo/_base/declare',
    'dojo/string',
    'Sage/Platform/Mobile/Edit'
], function(
    declare,
    string,
    Edit
) {
    return declare('Mobile.Template.Views.Account.Edit', [Edit], {
        // Localization
        titleText: 'Account Edit',
        accountNameText: 'account',
        industryText: 'business',
        accountManagerText: 'manager',
        webAddressText: 'web',
        mainPhoneText: 'phone',

        // Templates
        userInfoNameTemplate: new Simplate([
            '{% if ($) { %}',
                '{% if ($.LastName && $.FirstName) { %}',
                    '{%: $.LastName %}, {%= $.FirstName%}',
                '{% } else { %}',
                    '{%: $.LastName ? $.LastName : $.FirstName %}',
                '{% } %}',
            '{% } %}'
        ]),

        // View Properties
        id: 'account_edit',
        resourceKind: 'accounts',
        querySelect: [
            'AccountName',
            'AccountManager/UserInfo/*',
            'WebAddress',
            'MainPhone',
            'Industry'
        ],
        createLayout: function() {
            return this.layout || (this.layout = [{
                    name: 'AccountName',
                    property: 'AccountName',
                    label: this.accountNameText,
                    type: 'text'
                },{
                    name: 'AccountManager',
                    property: 'AccountManager',
                    label: this.accountManagerText,
                    textProperty: 'UserInfo',
                    textTemplate: this.userInfoNameTemplate,
                    type: 'lookup',
                    view: 'user_list'
                },{
                    name: 'Industry',
                    property: 'Industry',
                    label: this.industryText,
                    type: 'text'
                },{
                    name: 'WebAddress',
                    property: 'WebAddress',
                    label: this.webAddressText,
                    type: 'text',
                    inputType: 'url'
                },{
                    name: 'MainPhone',
                    property: 'MainPhone',
                    label: this.mainPhoneText,
                    type: 'phone'
                }]
            );
        }
    });
});