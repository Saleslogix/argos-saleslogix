define('Mobile/Template/Views/Account/Detail', [
    'dojo/_base/declare',
    'dojo/string',
    'Sage/Platform/Mobile/Format',
    'Sage/Platform/Mobile/Detail'
], function(
    declare,
    string,
    format,
    Detail
) {
    return declare('Mobile.Template.Views.Account.Detail', [Detail], {
        // Localization
        titleText: 'Account Detail',
        accountNameText: 'account',
        industryText: 'business',
        accountManagerText: 'manager',
        webAddressText: 'web',
        mainPhoneText: 'phone',
        detailsText: 'Details',
        contactInfoText: 'Contact Info',

        // Templates
        userInfoNameTemplate: new Simplate([
            '{% if ($) { %}',
                '{% if ($.LastName && $.FirstName) { %}',
                    '{%: $.LastName %}, {%= $.FirstName%}',
                '{% } else { %}',
                    '{%: $.LastName ? $.LastName : $.FirstName %}',
                '{% } %}',
            '{% } %}'
        ]),

        // View Properties
        id: 'account_detail',
        editView: 'account_edit',
        resourceKind: 'accounts',
        querySelect: [
            'AccountName',
            'AccountManager/UserInfo/*',
            'WebAddress',
            'MainPhone',
            'Industry'
        ],
        createLayout: function() {
            return this.layout || (this.layout = [{
                title: this.detailsText,
                name: 'DetailsSection',
                children: [{
                    name: 'AccountName',
                    property: 'AccountName',
                    label: this.accountNameText
                },{
                    name: 'Industry',
                    property: 'Industry',
                    label: this.industryText
                },{
                    name: 'AccountManager',
                    property: 'AccountManager.UserInfo',
                    label: this.accountManagerText,
                    tpl: this.userInfoNameTemplate
                }]
           },{
                title: this.contactInfoText,
                name: 'ContactInfoSection',
                children: [{
                    name: 'WebAddress',
                    property: 'WebAddress',
                    label: this.webAddressText,
                    renderer: format.link
                },{
                    name: 'MainPhone',
                    property: 'MainPhone',
                    label: this.mainPhoneText
                }]
            }]);
        }

    });
});