define('configuration/development', ['Mobile/Template/ApplicationModule'], function(ApplicationModule) {

    return {
        modules: [
            new ApplicationModule()
        ],
        connections: {
            'crm': {
                isDefault: true,
                offline: true,
                userName: 'lee',
                password: '',
                url: 'http://50.16.242.109/sdata/slx/dynamic/-/',
                json: true
            }
        }
    };

});