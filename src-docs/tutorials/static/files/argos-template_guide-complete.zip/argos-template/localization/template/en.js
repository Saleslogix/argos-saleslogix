define('localization/Template/en', ['localization/en', 'Mobile/Template/ApplicationModule'], function() {

/*
For localization overrides use: localize("Module Name", { property: "new value" });

localize("Mobile.Template.Views.Configure", {
  "titleText": "Konfigur.",
  "savePrefsText": "Speichern"
});

*/

});
